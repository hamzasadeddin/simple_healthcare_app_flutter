package com.example.pure_health_clinic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
